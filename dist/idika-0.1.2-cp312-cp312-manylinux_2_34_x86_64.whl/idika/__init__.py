from .idika import *

__doc__ = idika.__doc__
if hasattr(idika, "__all__"):
    __all__ = idika.__all__